require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const fs = require('fs');
const path = require('path');

const app = express();

// --- JWT Secrets ---
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
if (!process.env.JWT_SECRET) {
  console.warn('⚠️ Kein JWT_SECRET in .env gefunden, temporärer Token generiert! Tokens ungültig nach Neustart.');
}
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || JWT_SECRET;

// --- Config ---
const PORT = process.env.PORT || 3000;

const ALLOWED_ORIGINS = [
  'http://localhost:8080',
  'http://127.0.0.1:5500',
  'http://localhost:3000',
  'http://localhost:8000'
];

// Path to the users.json file
const USERS_FILE = path.join(__dirname, 'users.json');

// --- Middleware ---
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || ALLOWED_ORIGINS.includes(origin)) {
      callback(null, true);
    } else {
      console.warn(`CORS Blockiert: Herkunft ${origin}`);
      callback(new Error('CORS blockiert diese Herkunft'));
    }
  },
  credentials: true
}));

app.use(express.json());
app.use(morgan('combined'));

// --- Rate Limiting ---
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Zu viele Anfragen, bitte später versuchen.' }
});
app.use('/api/login', authLimiter);
app.use('/api/register', authLimiter);

// --- Helper to read users.json ---
function readUsers() {
  try {
    const data = fs.readFileSync(USERS_FILE);
    return JSON.parse(data);
  } catch (err) {
    console.error('Fehler beim Lesen der users.json:', err);
    return [];
  }
}

// --- Helper to save users to users.json ---
function saveUsers(users) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error('Fehler beim Speichern von users.json:', err);
  }
}

// --- Auth Middleware ---
async function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token fehlt' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Token ungültig oder abgelaufen' });
    req.user = user;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'Adminrechte erforderlich' });
  }
  next();
}

// --- Password Validation ---
function validatePassword(password) {
  const regex = /^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
  return regex.test(password);
}

// --- Routes ---

// Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: 'Benutzername und Passwort erforderlich' });
    if (!validatePassword(password))
      return res.status(400).json({
        error:
          'Passwort muss min. 8 Zeichen, 1 Zahl, 1 Großbuchstaben und 1 Sonderzeichen enthalten'
      });

    const users = readUsers();
    const userExists = users.find(user => user.username === username);
    if (userExists) {
      return res.status(400).json({ error: 'Benutzername bereits vergeben' });
    }

    const hashed = await bcrypt.hash(password, 12);
    const newUser = { 
      id: Date.now(), 
      username, 
      password: hashed, 
      isAdmin: false,
      twoFACode: crypto.randomBytes(3).toString('hex') // generate random 6-digit 2FA code
    };

    users.push(newUser);
    saveUsers(users);

    res.status(201).json({ message: 'Benutzer registriert' });
  } catch (err) {
    console.error('Fehler bei Registrierung:', err);
    res.status(500).json({ error: 'Interner Serverfehler' });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { username, password, twoFACode } = req.body;
    const users = readUsers();
    const user = users.find(user => user.username === username);
    if (!user) return res.status(400).json({ error: 'Ungültige Anmeldedaten' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Ungültige Anmeldedaten' });

    if (twoFACode && twoFACode !== user.twoFACode) {
      return res.status(400).json({ error: 'Ungültiger 2FA-Code' });
    }

    const accessToken = jwt.sign(
      { id: user.id, username: user.username, isAdmin: user.isAdmin },
      JWT_SECRET,
      { expiresIn: '15m' }
    );
    const refreshToken = jwt.sign(
      { id: user.id, username: user.username },
      JWT_REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    res.json({ accessToken, refreshToken });
  } catch (err) {
    console.error('Fehler beim Login:', err);
    res.status(500).json({ error: 'Interner Serverfehler' });
  }
});

// Refresh Token
app.post('/api/token', async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(401).json({ error: 'Refresh Token fehlt' });

  jwt.verify(token, JWT_REFRESH_SECRET, async (err, user) => {
    if (err) return res.status(403).json({ error: 'Refresh Token abgelaufen oder ungültig' });

    const accessToken = jwt.sign(
      { id: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '15m' }
    );
    res.json({ accessToken });
  });
});

// Logout
app.post('/api/logout', async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'Refresh Token erforderlich' });

  res.status(204).send();
});

// --- Server starten ---
app.listen(PORT, () => {
  console.log(`Server läuft auf Port ${PORT}`);
});
