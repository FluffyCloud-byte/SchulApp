// backend/index.js

require('dotenv').config();
const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const app = express();

// Konfiguration
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dein_geheimer_schluessel_123456789';
const ALLOWED_ORIGINS = [
  'http://localhost:8080',
  'http://127.0.0.1:5500',
  'http://localhost:5500',
  null
];
const FILES = {
  USERS: path.join(__dirname, 'users.json'),
  ORDERS: path.join(__dirname, 'orders.json'),
  MENU: path.join(__dirname, 'menu.json')
};

// Middleware
app.use(cors({
  origin: (origin, callback) => {
    if (ALLOWED_ORIGINS.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS blockiert diese Herkunft: ' + origin));
    }
  },
  credentials: true
}));
app.use(express.json());
app.use(morgan('combined'));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 5 });
app.use('/api/login', limiter);
app.use('/api/register', limiter);

// Schreib‑Locking für sichere Dateioperationen
let writeLock = Promise.resolve();

async function safeReadJSON(file, fallback = []) {
  try {
    const txt = await fs.readFile(file, 'utf8');
    return JSON.parse(txt);
  } catch (err) {
    if (err.code === 'ENOENT') {
      return fallback;
    }
    throw err;
  }
}

async function safeWriteJSON(file, data) {
  writeLock = writeLock
    .then(() => fs.writeFile(file + '.tmp', JSON.stringify(data, null, 2), 'utf8'))
    .then(() => fs.rename(file + '.tmp', file))
    .catch(err => {
      console.error('Fehler beim sicheren Schreiben:', err);
      throw err;
    });
  return writeLock;
}

async function readMenu() {
  return safeReadJSON(FILES.MENU, { gerichte: [], getraenke: [] });
}
async function writeMenu(data) {
  return safeWriteJSON(FILES.MENU, data);
}

// Auth Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Token fehlt' });
  }
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token ungültig' });
    }
    req.user = user;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'Adminrechte erforderlich' });
  }
  next();
}

// Routen

// Registrierung
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username und Passwort benötigt' });
  }
  const users = await safeReadJSON(FILES.USERS, []);
  if (users.find(u => u.username === username)) {
    return res.status(409).json({ error: 'Benutzername schon vergeben' });
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = {
    id: Date.now(),
    username,
    password: hashedPassword,
    isAdmin: false
  };
  users.push(newUser);
  await safeWriteJSON(FILES.USERS, users);
  res.status(201).json({ message: 'Benutzer registriert' });
});

// Login
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const users = await safeReadJSON(FILES.USERS, []);
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ error: 'Ungültige Anmeldedaten' });
  }
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    return res.status(401).json({ error: 'Ungültige Anmeldedaten' });
  }

  const token = jwt.sign(
    { id: user.id, username: user.username, isAdmin: user.isAdmin },
    JWT_SECRET,
    { expiresIn: '1h' }
  );
  res.json({ token });
});

// Bestellung aufgeben (Nutzername als Name)
app.post('/api/bestellung', authenticateToken, async (req, res) => {
  const { gericht, menge, getraenk, bemerkung } = req.body;
  if (!gericht || !menge) {
    return res.status(400).json({ error: 'Pflichtfelder fehlen' });
  }
  const orders = await safeReadJSON(FILES.ORDERS, []);
  const newOrder = {
    id: Date.now(),
    userId: req.user.id,
    name: req.user.username,  // Name aus JWT
    gericht,
    menge,
    getraenk: getraenk || '',
    bemerkung: bemerkung || '',
    createdAt: new Date().toISOString()
  };
  orders.push(newOrder);
  await safeWriteJSON(FILES.ORDERS, orders);
  res.status(201).json({ message: 'Bestellung gespeichert' });
});

// Alle Bestellungen (Admin)
app.get('/api/bestellungen', authenticateToken, requireAdmin, async (req, res) => {
  const orders = await safeReadJSON(FILES.ORDERS, []);
  res.json(orders);
});

// Menü abrufen (für Nutzer)
app.get('/api/menu', authenticateToken, async (req, res) => {
  const menu = await readMenu();
  res.json(menu);
});

// Admin: Gericht hinzufügen
app.post('/api/admin/gerichte', authenticateToken, requireAdmin, async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Name fehlt' });
  }
  const menu = await readMenu();
  if (menu.gerichte.find(g => g.name.toLowerCase() === name.toLowerCase())) {
    return res.status(409).json({ error: 'Gericht existiert bereits' });
  }
  const newGericht = { id: Date.now(), name };
  menu.gerichte.push(newGericht);
  await writeMenu(menu);
  res.status(201).json({ message: 'Gericht hinzugefügt' });
});

// Server starten
app.listen(PORT, () => {
  console.log(`✅ Server läuft auf http://localhost:${PORT}`);
});
