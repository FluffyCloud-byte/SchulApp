require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const fs = require('fs');
const path = require('path');

const app = express();

// --- JWT Secrets (unverändert) ---
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
if (!process.env.JWT_SECRET) {
  console.warn('⚠️ Kein JWT_SECRET in .env gefunden, temporärer Token generiert! Tokens ungültig nach Neustart.');
}
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || JWT_SECRET;

// --- Config (unverändert) ---
const PORT = process.env.PORT || 3000;
const ALLOWED_ORIGINS = [
  'http://localhost:8080',
  'http://127.0.0.1:5500', // Wichtig für Live Server (VS Code)
  'http://localhost:3000',
  'http://localhost:8000'
];

// --- *** NEUE DATEI-PFADE *** ---
const USERS_FILE = path.join(__dirname, 'users.json');
const ORDERS_FILE = path.join(__dirname, 'orders.json'); // NEU

// --- Middleware (unverändert) ---
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || ALLOWED_ORIGINS.includes(origin)) {
      callback(null, true);
    } else {
      console.warn(`CORS Blockiert: Herkunft ${origin}`);
      callback(new Error('CORS blockiert diese Herkunft'));
    }
  },
  credentials: true
}));
app.use(express.json());
app.use(morgan('combined'));

// --- Rate Limiting (unverändert) ---
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 10, // Leicht erhöht
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Zu viele Anfragen, bitte später versuchen.' }
});
app.use('/api/login', authLimiter);
app.use('/api/register', authLimiter);

// --- *** HELPER-FUNKTIONEN ANGEPASST *** ---

// User-Helfer (unverändert)
function readUsers() {
  try {
    if (!fs.existsSync(USERS_FILE)) {
        fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2)); // Erstelle leere Datei, falls nicht existent
    }
    const data = fs.readFileSync(USERS_FILE);
    return JSON.parse(data);
  } catch (err) {
    console.error('Fehler beim Lesen der users.json:', err);
    return [];
  }
}
function saveUsers(users) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error('Fehler beim Speichern von users.json:', err);
  }
}

// NEU: Order-Helfer
function readOrders() {
  try {
    if (!fs.existsSync(ORDERS_FILE)) {
        fs.writeFileSync(ORDERS_FILE, JSON.stringify([], null, 2)); // Erstelle leere Datei
    }
    const data = fs.readFileSync(ORDERS_FILE);
    return JSON.parse(data);
  } catch (err) {
    console.error('Fehler beim Lesen der orders.json:', err);
    return [];
  }
}
function saveOrders(orders) {
  try {
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
  } catch (err)
 {
    console.error('Fehler beim Speichern von orders.json:', err);
  }
}

// NEU: Funktion zur Generierung des Bestellcodes
function generateOrderCode() {
    // Generiert einen 3-stelligen Code (100-999)
    // Für ein echtes System würde man hier prüfen, ob der Code bereits
    // für eine 'pending' Bestellung aktiv ist, aber für diese Demo reicht das.
    return Math.floor(100 + Math.random() * 900).toString();
}


// --- Auth Middleware (unverändert) ---
async function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token fehlt' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Token ungültig oder abgelaufen' });
    req.user = user;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'Adminrechte erforderlich' });
  }
  next();
}

// Password Validation (unverändert)
function validatePassword(password) {
  const regex = /^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
  return regex.test(password);
}

// --- Auth Routes (Registrierung, Login, etc. - unverändert) ---
app.post('/api/register', async (req, res) => {
    // ... (dein Registrierungs-Code, unverändert) ...
    try {
      const { username, password } = req.body;
      if (!username || !password)
        return res.status(400).json({ error: 'Benutzername und Passwort erforderlich' });
      if (!validatePassword(password))
        return res.status(400).json({
          error:
            'Passwort muss min. 8 Zeichen, 1 Zahl, 1 Großbuchstaben und 1 Sonderzeichen enthalten'
        });

      const users = readUsers();
      const userExists = users.find(user => user.username === username);
      if (userExists) {
        return res.status(400).json({ error: 'Benutzername bereits vergeben' });
      }

      const hashed = await bcrypt.hash(password, 12);
      const newUser = { 
        id: Date.now(), 
        username, 
        password: hashed, 
        isAdmin: false,
        // 2FA ist hier nicht im Frontend implementiert, aber wir lassen es im Modell
        twoFACode: crypto.randomBytes(3).toString('hex') 
      };

      users.push(newUser);
      saveUsers(users);

      res.status(201).json({ message: 'Benutzer registriert' });
    } catch (err) {
      console.error('Fehler bei Registrierung:', err);
      res.status(500).json({ error: 'Interner Serverfehler' });
    }
});

app.post('/api/login', async (req, res) => {
    // ... (dein Login-Code, unverändert, aber stelle sicher, dass 2FA optional ist) ...
    try {
        const { username, password, twoFACode } = req.body;
        const users = readUsers();
        const user = users.find(user => user.username === username);
        if (!user) return res.status(400).json({ error: 'Ungültige Anmeldedaten' });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Ungültige Anmeldedaten' });

        // ANNAHME: 2FA ist hier optional oder wird (noch) nicht genutzt.
        // if (user.twoFAEnabled && twoFACode !== user.twoFACode) {
        //   return res.status(400).json({ error: 'Ungültiger 2FA-Code' });
        // }

        const accessToken = jwt.sign(
            { id: user.id, username: user.username, isAdmin: user.isAdmin },
            JWT_SECRET,
            { expiresIn: '1h' } // 1 Stunde statt 15min für bessere UX
        );
        const refreshToken = jwt.sign(
            { id: user.id, username: user.username },
            JWT_REFRESH_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ accessToken, refreshToken }); // Sende accessToken
    } catch (err) {
        console.error('Fehler beim Login:', err);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
});

app.post('/api/token', async (req, res) => {
    // ... (dein Token-Refresh-Code, unverändert) ...
    const { token } = req.body;
    if (!token) return res.status(401).json({ error: 'Refresh Token fehlt' });

    // Finde den User basierend auf dem Refresh-Token
    const users = readUsers();

    jwt.verify(token, JWT_REFRESH_SECRET, async (err, decodedUser) => {
      if (err) return res.status(403).json({ error: 'Refresh Token abgelaufen oder ungültig' });

      // Hole aktuelle User-Daten (wichtig, falls sich Admin-Status ändert)
      const user = users.find(u => u.id === decodedUser.id);
      if (!user) return res.status(403).json({ error: 'Benutzer nicht gefunden' });

      const accessToken = jwt.sign(
        { id: user.id, username: user.username, isAdmin: user.isAdmin }, // isAdmin in Token aufnehmen
        JWT_SECRET,
        { expiresIn: '1h' } // 1 Stunde
      );
      res.json({ accessToken });
    });
});

app.post('/api/logout', async (req, res) => {
  // ... (dein Logout-Code, unverändert) ...
  // (Normalerweise würde man hier Refresh-Tokens auf eine Blacklist setzen)
  res.status(204).send();
});


// --- *** NEUE BESTELL-ROUTEN *** ---

// POST /api/bestellung
// Eine neue Bestellung aufgeben
app.post('/api/bestellung', authenticateToken, async (req, res) => {
    try {
        const { gericht, menge, getraenk, bemerkung } = req.body;
        
        if (!gericht || !menge || menge < 1) {
            return res.status(400).json({ error: 'Gericht und Menge sind erforderlich.' });
        }

        const orders = readOrders();
        const newOrderCode = generateOrderCode();
        
        const newOrder = {
            id: Date.now().toString(), // ID als String
            userId: req.user.id,       // Vom Token
            name: req.user.username, // Vom Token
            gericht,
            menge,
            getraenk: getraenk || 'Keines',
            bemerkung: bemerkung || '',
            orderCode: newOrderCode,
            status: 'pending', // Status: 'pending' oder 'abgeholt'
            createdAt: new Date().toISOString()
        };

        orders.push(newOrder);
        saveOrders(orders);

        // WICHTIG: Sende den Code zurück an das Frontend
        res.status(201).json({ 
            message: 'Bestellung erfolgreich erstellt', 
            orderCode: newOrderCode 
        });

    } catch (err) {
        console.error('Fehler beim Erstellen der Bestellung:', err);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
});

// GET /api/bestellungen
// Alle Bestellungen abrufen (nur für Admins)
app.get('/api/bestellungen', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const orders = readOrders();
        // Sortiere, sodass die neuesten (höchste ID/Datum) oben sind
        orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        res.json(orders);
    } catch (err) {
        console.error('Fehler beim Laden der Bestellungen:', err);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
});

// PUT /api/bestellung/:id/status
// Status einer Bestellung ändern (nur für Admins)
app.put('/api/bestellung/:id/status', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body; // Erwartet: { status: 'abgeholt' } oder { status: 'pending' }

        if (!status || !['pending', 'abgeholt'].includes(status)) {
            return res.status(400).json({ error: 'Ungültiger Status' });
        }

        const orders = readOrders();
        const orderIndex = orders.findIndex(o => o.id === id);

        if (orderIndex === -1) {
            return res.status(404).json({ error: 'Bestellung nicht gefunden' });
        }

        orders[orderIndex].status = status;
        saveOrders(orders);

        res.json({ message: 'Status aktualisiert', order: orders[orderIndex] });

    } catch (err) {
        console.error('Fehler beim Aktualisieren des Status:', err);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
});


// --- Server starten (unverändert) ---
app.listen(PORT, () => {
  // Erstelle JSON-Dateien, falls sie nicht existieren
  readUsers();
  readOrders();
  console.log(`Server läuft auf Port ${PORT}`);
});